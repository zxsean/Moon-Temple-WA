# [2.8.1](https://github.com/WeakAuras/WeakAuras2/tree/2.8.1) (2018-10-02)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.8.0...2.8.1)

## Highlights

 We fixed a bug where conditions were not properly resetting when auras got unloaded. 

## Commits

Causese (1):

- fixed a trait that is no longer a buff on player

Infus (1):

- Fix Conditions not resetting on unloading auras

